# Pitch de 3 minutos — versão 5 (decisão de AQUISIÇÃO de imóvel)

### Roteiro final para o vídeo · tom formal, linguagem simples · ~400 palavras

**Por que esta versão:** o desafio é a decisão de **adquirir um imóvel pronto** (não desenvolver/SPOT). Esta versão entrega a resposta de compra de forma direta, mantendo a demonstração de senso crítico (revisar a própria conclusão) que vale pontos na avaliação.

---

**[Abertura — ~8s]**

Recebi a base real de Itapema — Airbnb e VivaReal — para indicar à Seazone **qual imóvel adquirir hoje**. Vou responder às perguntas com dados, com a estimativa de retorno e com a razão da escolha.

**[1. Qual o melhor perfil (Q1) — ~30s]**

O melhor perfil é um **apartamento de 2 quartos**. A receita do imóvel sobe com a capacidade — cada quarto a mais soma, em mediana, cerca de dois mil reais por mês. Dois quartos é o ponto de equilíbrio: rende quase como os imóveis maiores, mas custa bem menos. Apartamento domina o mercado — 84% dos anúncios — e é o mais fácil de comprar e revender. E dentro do condomínio há um detalhe que muda tudo: o **elevador**, a única instalação cujo ganho de receita compensa quanto encarece a compra. Piscina e academia custam mais do que devolvem.

**[2. Localização (Q2) — ~15s]**

Em receita bruta, Meia Praia lidera — sete mil e quatrocentos reais por mês. Mas o critério de investimento não é receita, é **retorno sobre o capital**. Por ele, bairros mais baratos, como **Morretes**, entregam mais: o imóvel custa menos e a receita não cai na mesma proporção.

**[3. O que explica a receita (Q3) — ~20s]**

O que mais pesa na receita, além da capacidade, é o **elevador** e o **estacionamento** — o hóspede de praia chega de carro. Nota do anúncio e reputação do anfitrião quase não importam. Isso direciona a escolha: priorizar capacidade e essas instalações, não fama.

**[4. A tese interna — ~20s]**

A tese da Seazone de "estúdio/1 quarto no Centro" **não se sustenta** nos dados. Existem só três estúdios no Centro inteiro, e compactos no Centro rendem menos da metade de um apartamento maior no mesmo bairro, com o metro quadrado mais caro. O caminho não é compacto — é **capacidade** — e não o Centro.

**[5. Testando a escolha (senso crítico) — ~25s]**

Validei essa opção com testes de robustez. O 2 quartos em Morretes tem 47 anúncios com calendário confiável, e o yield líquido — já com condomínio e IPTU reais — fica em cerca de **7% ao ano**, empatado dentro do erro com o compacto de Meia Praia. Diante do empate, Morretes vence pelo preço menor de entrada.

**[6. O que comprar e retorno (Q4) — ~35s]**

A recomendação: comprar um **apartamento de 2 quartos em Morretes, com elevador**, por **cerca de 750 mil reais**, com retorno líquido de **7% ao ano**, comprado à vista. Isso é competitivo com o padrão da própria Seazone: o case dela no Centro (Manhattan Flats) projeta cerca de oito por cento. E financiar não compensa: hoje o financiamento é maior que o retorno do imóvel — então é compra à vista.

**[Como usei IA — ~15s]**

Usei IA para cruzar as cinco bases, montar o modelo de retorno, pesquisar taxas reais de mercado e, o mais importante, tentar derrubar a própria conclusão. Todo o processo está registrado na pasta `ai-log`.

**[Com mais uma semana — ~18s]**

Com mais uma semana, eu buscaria dados reais de ocupação — hoje é uma estimativa a partir do calendário — e a geolocalização exata do imóvel até a faixa de areia, além de validar custos de aquisição e gestão com fornecedores.

**[Fechamento — ~10s]**

Em uma frase: para a Seazone, a aquisição mais defensável hoje é um **apartamento de 2 quartos, com elevador, em Morretes, por 750 mil reais e cerca de 7% ao ano** — e a tese do compacto no Centro não se sustenta nos dados.

---

*Nota de prática: câmera; números sempre arredondados (~7%, 750 mil, 2 quartos, Meia Praia R$ 7,4 mil/mês); manter a comparação com o case da própria Seazone para justificar a "melhor escolha".*